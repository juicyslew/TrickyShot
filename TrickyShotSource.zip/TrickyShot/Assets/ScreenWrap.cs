﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ScreenWrap : MonoBehaviour {

	//private bool isWrappingX = false;
	//private bool isWrappingY = false;

	private Camera cam;

	private float scrH;
	private float scrW;

	private Transform[] ghosts = new Transform[8];

	public GameObject ghostObj;

	private float[] gposesx = new float[]{-1,-1,0,1,1,1,0,-1};
	private float[] gposesy = new float[]{0,-1,-1,-1,0,1,1,1};

	// private Renderer[] renderers;
	// Use this for initialization
	void Start () {
		//renderers = GetComponentsInChildren<Renderer> ();
		cam = Camera.main;

		Vector3 scrBL = cam.ViewportToWorldPoint (new Vector3 (0, 0, transform.position.z));
		Vector3 scrTR = cam.ViewportToWorldPoint (new Vector3 (1, 1, transform.position.z));

		scrW = scrTR.x - scrBL.x;
		scrH = scrTR.y - scrBL.y;

		MakeGhosts ();
	}
	
	// Update is called once per frame
	void Update () {
		SwapGhosts ();
	}

	void MakeGhosts(){
		for (int i = 0; i < 8; i++){
			ghosts[i] = Instantiate(ghostObj, Vector3.zero, Quaternion.identity).transform;
		}
		PositionGhosts ();
	}

	void PositionGhosts(){
		for (int i = 0; i < 8; i++) {
			ghosts[i].position = transform.position + new Vector3(gposesx[i]*scrW, gposesy[i]*scrH, 0);
			ghosts[i].rotation = transform.rotation;
		}
	}

	void SwapGhosts(){
		float scrleft = cam.transform.position.x - scrW/2f;
		float scrright = cam.transform.position.x + scrW/2f; 
		float scrup = cam.transform.position.y + scrH/2f; 
		float scrdown = cam.transform.position.y - scrH/2f; 
		foreach (Transform ghost in ghosts) {
			if (ghost.position.x < scrright && ghost.position.x > scrleft &&
				ghost.position.y < scrup && ghost.position.y > scrdown) {

				transform.position = ghost.position;
				break;
			}
		}
		PositionGhosts ();
	}


	/*void Wrapping(){
		bool visible = CheckRenderers ();

		if (visible) {
			isWrappingY = false;
			isWrappingX = false;
			return;
		}

		if (isWrappingY && isWrappingX) {
			return;
		}


		var viewportPosition = cam.WorldToViewportPoint (transform.position);
		var newpos = transform.position;
		var campos = cam.transform.position;

		if (!isWrappingX && (viewportPosition.x > 1f || viewportPosition.x < 0f)) {
			newpos.x = campos.x + (campos.x - newpos.x);
			isWrappingX = true;
		}

		if (!isWrappingY && (viewportPosition.y > 1f || viewportPosition.y < 0f)) {
			newpos.y = campos.y + (campos.y - newpos.y);
			isWrappingY = true;
		}

		transform.position = newpos;
	}*/

	/*bool CheckRenderers(){
	foreach (Renderer r in renderers) {
		if (r.isVisible) {
			return true;
		}
	}
	return false;
	}*/
}
