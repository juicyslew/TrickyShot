﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PickupSpawner : AbstractSpawner {
	public override GameObject RandomSpawn(Vector3 loc){
		GameObject obj = base.RandomSpawn (loc);
		AbstractPickup pickup = obj.GetComponent<AbstractPickup> ();
		pickup.spawner = this;
		return obj;
	}
}
