﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PlayerScript : GenericCharacter {

	//public float mass;
	//public Vector2 vel;
	//public 
	//private Vector3 scrCenter;

	public Vector2 mousepos = new Vector2(0,0);
	private float mousedistlimit = 8f;
	private float slowspeed = .1f;
	private float closest_bullet = 1f;
	private float respeed = .3f;

	// Use this for initialization
	protected override void Start () {
		//scrCenter = Camera.main.ViewportToScreenPoint (new Vector3 (.5f, .5f, 0f));
		base.Start();
		Cursor.lockState = CursorLockMode.Locked;
	}
	
	// Update is called once per frame
	protected override void Update () {
		MoveMouse ();
		FaceMouse();

		SetGameSpeed ();
		base.Update ();
	}

	void LateUpdate(){
		closest_bullet += (1/respeed)*Time.unscaledDeltaTime;
	}

	void MoveMouse(){
		Vector2 mousevel = new Vector2(Input.GetAxis("Mouse X"), Input.GetAxis("Mouse Y"));

		mousepos += (Vector2) mousevel;
		if (mousepos.magnitude > mousedistlimit){
			mousepos = mousedistlimit * mousepos.normalized;
		}
	}

	void FaceMouse(){
		Vector2 lookdir = new Vector2 (mousepos.x, mousepos.y);
		transform.up = lookdir;
	}

	void SetGameSpeed(){
		if (closest_bullet < 1) {
			Time.timeScale = closest_bullet * (1 - slowspeed) + slowspeed;
		} else {
			Time.timeScale = 1f;
		}
	}

	public void GiveCloseness(float closeness){
		if (closeness < closest_bullet) {
			closest_bullet = closeness;
		}
	}

	public override void Die(){
		Camera.main.GetComponent<CameraShake> ().CamShake (.3f);
		GameObject.FindGameObjectWithTag ("GameController").GetComponent<GameControllerScript>().GameOver();
		DeathSound();
	}
}