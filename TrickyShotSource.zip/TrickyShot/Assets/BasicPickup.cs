﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class BasicPickup : AbstractPickup {

	protected override void PickupEffect ()
	{
		base.PickupEffect ();
		Destroy (gameObject);
	}
}
