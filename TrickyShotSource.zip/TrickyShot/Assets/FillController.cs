﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class FillController : MonoBehaviour {

	private Image myimage;

	// Use this for initialization
	void Start () {
		myimage = GetComponent<Image> ();
	}


	public void SetFill(float v){
		myimage.fillAmount = v;
	}

	public float GetFill(){ 
		return myimage.fillAmount;
	}
}
