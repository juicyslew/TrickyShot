﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class BombClearSpecial : AbstractSpecial {

	protected void OnTriggerStay2D(Collider2D col){
		if (col.gameObject.layer == LayerMask.NameToLayer ("Bullets")) {
			Destroy (col.gameObject);
		}
		if (col.gameObject.layer == LayerMask.NameToLayer ("Enemies")) {
			col.GetComponent<AbstractEnemy> ().Die();
		}
	}
}
