﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Shooter : MonoBehaviour {

	public GameObject shotType;
	public float projmult;
	public float specialInterval;
	private float specialTimer = 0f;
	public GameObject special;
	private FillController specialFill;
	private bool specialfull = false;
	public AudioSource specialFilled;
	public AudioSource specialUsed;

	//private GameObject GameController;

	// Use this for initialization
	void Start () {
		specialFill = GameObject.FindGameObjectWithTag ("SpecialFill").GetComponent<FillController> ();
	}
	
	// Update is called once per frame
	void Update () {
		Shoot();
		UpdateFills ();
		specialTimer += Time.deltaTime;
	}
	void Shoot(){
		if (Input.GetButtonDown("Shoot")){
			transform.parent.GetComponent<PlayerScript> ().shootsource.Play() ;
			float shotspd = shotType.GetComponent<AbstractBullet> ().speed;
			GameObject bullet = Instantiate (shotType, transform.position, transform.rotation);
			AbstractBullet velscript = bullet.GetComponent<AbstractBullet>();
			velscript.speed = shotspd * projmult;
			velscript.player = transform.parent.gameObject.GetComponent<GenericCharacter>();
			Camera.main.GetComponent<CameraShake> ().CamShake (.07f);
		}
		if (Input.GetButtonDown("Special") && specialTimer > specialInterval){
			specialfull = false;
			specialTimer = 0;
			specialUsed.Play ();
			Instantiate (special, transform.position, transform.rotation);
			Camera.main.GetComponent<CameraShake> ().CamShake (.7f);

		}
	}
	void UpdateFills(){
		if (specialTimer > specialInterval && !specialfull) {
			specialfull = true;
			specialFilled.Play ();
		}
		specialFill.SetFill (Mathf.Min (specialTimer / specialInterval, 1));
	}
}
