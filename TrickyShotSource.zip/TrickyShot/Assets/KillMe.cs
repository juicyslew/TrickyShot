﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class KillMe : MonoBehaviour {

	private float killTimer = 0f;
	public float killInterval;

	// Use this for initialization
	void Start () {
		
	}
	
	// Update is called once per frame
	void Update () {
		if (killTimer > killInterval) {
			Destroy (gameObject);
		}
		killTimer += killInterval * Time.deltaTime;
	}
}
