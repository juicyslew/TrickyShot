﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class CircularShot : AbstractBullet {

	private float[] circleRadiusRange = new float[]{.5f, 2f};
	protected float vel;
	public float mass = 3f;
	protected Rigidbody2D mybody;
	protected float circrad;
	//protected Vector3 origin;
	protected float myang;
	protected Vector2 myvel;

	public override void Start(){
		base.Start ();
		mybody = GetComponent<Rigidbody2D> ();
		mybody.velocity = new Vector2 (0, 0); 
		startForce = startForce / mass;
		myvel = startForce; 
		circrad = Random.value * (circleRadiusRange [1] - circleRadiusRange [0]) + circleRadiusRange [0];
		if (Random.value > .5f) {
			circrad = -circrad;
		}
		Debug.Log (circrad);

	}

	// Update is called once per frame
	public void FixedUpdate () {
		Vector3 origin = transform.position + circrad * new Vector3(-myvel.y, myvel.x, 0).normalized;
		float angdiff = myvel.magnitude / circrad * Time.fixedDeltaTime;
		transform.RotateAround (origin, transform.forward, angdiff * Mathf.Rad2Deg );
		myang += angdiff;
		float sinang = Mathf.Sin(myang);
		float cosang = Mathf.Cos(myang);
		myvel = new Vector2(
			-sinang * startForce.y + cosang * startForce.x,
			sinang * startForce.x + cosang *startForce.y);

	}
}
