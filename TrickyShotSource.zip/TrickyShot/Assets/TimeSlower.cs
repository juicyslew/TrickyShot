﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class TimeSlower : MonoBehaviour {

	//private AbstractBullet bulletscript;
	// Use this for initialization
	private float slowerRadius;
	private float effectWaitInterval = .5f;
	private float effectTimer = 0f;
	void Start () {
		slowerRadius = GetComponent<CircleCollider2D> ().radius + GameObject.FindGameObjectWithTag("Player").GetComponent<CircleCollider2D>().radius;
		//bulletscript = transform.parent.GetComponent<AbstractBullet> ();
	}
	
	// Update is called once per frame
	void Update () {
		effectTimer += Time.deltaTime;
	}

	public void OnTriggerStay2D(Collider2D col){
		if (effectTimer > effectWaitInterval && col.gameObject.tag == "Player"){
			col.GetComponent<PlayerScript>().GiveCloseness((col.transform.position - transform.position).magnitude/slowerRadius);
		}
	}

}
