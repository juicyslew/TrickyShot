﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class AbstractBullet : MonoBehaviour {

	public float speed;
	public float damage = 35f;
	public Vector2 startForce;
	public GenericCharacter player;
	protected GameControllerScript GameController;
	protected float immunetimer = .005f;

	// Use this for initialization
	public virtual void Start () {
		startForce = (Vector2)(transform.up * speed);
		GetComponent<Rigidbody2D> ().AddForce (startForce, ForceMode2D.Impulse);
		player.GetComponent<Rigidbody2D> ().AddForce ( (player.bulletLocked) ? new Vector2(0,0) : -startForce, ForceMode2D.Impulse);
		GameController = GameObject.FindGameObjectWithTag("GameController").GetComponent<GameControllerScript> ();
		GameController.bullets += 1;
	}

	// Update is called once per frame
	public virtual void Update () {
		immunetimer -= Time.deltaTime;
	}

	public virtual void OnTriggerEnter2D(Collider2D col){
		if ((col.gameObject.tag == "Player" || col.gameObject.tag == "Enemy") && immunetimer < 0){
			GenericCharacter c = col.GetComponent<GenericCharacter> ();
			c.TakeDamage(damage);
			c.hitsource.Play ();
			Camera.main.GetComponent<CameraShake> ().CamShake (.07f);

			Destroy (gameObject);
		}
	}
}
