﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public abstract class AbstractPickup : MonoBehaviour {

	private GameControllerScript GameController;
	public PickupSpawner spawner;
	public GameObject pickupsource;

	// Use this for initialization
	protected virtual void Start () {
		GameController = GameObject.FindGameObjectWithTag("GameController").GetComponent<GameControllerScript> ();
	}

	protected virtual void OnTriggerEnter2D(Collider2D col){
		if (col.gameObject.tag == "Player"){
			GameController.collected += 1;
			PickupEffect ();
		}
	}

	protected virtual void PickupEffect ()
	{
		Instantiate (pickupsource, transform.position, Quaternion.identity);
		spawner.numActiveObj -= 1;
	}
}
