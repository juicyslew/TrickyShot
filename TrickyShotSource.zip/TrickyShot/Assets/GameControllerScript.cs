﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;
using UnityEngine.UI;

public class GameControllerScript : MonoBehaviour {

	public enum Objective {Bullets, Survival, Collect, Fight};
	public Objective goaltype;

	public int bullets;
	public int bulletsGoal;

	private float survivalTimer;
	public float survivalTimerGoal;

	public int collected;
	public int collectGoal;

	public int fightnum;
	public int fightGoal;

	public GameObject HUD;
	public GameObject WinScreen;
	public GameObject GameOverScreen;
	public string nextLevelName;

	private enum activeUI {HUD, Win, Over};
	private activeUI currentUI = activeUI.HUD;
	private Image progressbar;

	// Use this for initialization
	void Start () {
		Screen.fullScreen = true;
		progressbar = GameObject.FindGameObjectWithTag ("Progress").GetComponent<Image>();
	}
	
	// Update is called once per frame
	void Update () {
		Check_Win ();
		survivalTimer += Time.deltaTime;
	}

	public void Check_Win(){
		switch (goaltype) {
		case Objective.Bullets:
			if (bullets >= bulletsGoal) {
				Win ();
			}
			progressbar.fillAmount = (float) bullets / bulletsGoal;
			break;
		case Objective.Survival:
			if (survivalTimer >= survivalTimerGoal) {
				Win ();
			}
			progressbar.fillAmount = survivalTimer / survivalTimerGoal;
			break;
		case Objective.Collect:
			if (collected >= collectGoal) {
				Win ();
			}
			progressbar.fillAmount = (float) collected / collectGoal;
			break;
		case Objective.Fight:
			if (fightnum >= fightGoal) {
				Win ();
			}
			progressbar.fillAmount = (float) fightnum / fightGoal;
			break;
		}
	}

	public void Win(){
		if (currentUI == activeUI.HUD) {
			WinScreen.SetActive (true);
			currentUI = activeUI.Win;
			Cursor.lockState = CursorLockMode.None;
		}
	}

	public void GameOver(){
		if (currentUI == activeUI.HUD) {
			GameOverScreen.SetActive (true);
			currentUI = activeUI.Over;
			Cursor.lockState = CursorLockMode.None;
		}
	}

	public void NextLevel(){
		SceneManager.LoadScene (nextLevelName, LoadSceneMode.Single);
	}

	public void Restart(){
		SceneManager.LoadScene (SceneManager.GetActiveScene().buildIndex, LoadSceneMode.Single);
	}
}
