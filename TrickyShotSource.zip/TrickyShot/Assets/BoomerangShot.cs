﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class BoomerangShot : AbstractBullet {

	public float reboundstrength; 
	protected float maxvel; 
	protected Vector2 initvel;
	protected Rigidbody2D mybody;
	protected bool boomeranging = true;

	public override void Start(){
		base.Start ();
		mybody = GetComponent<Rigidbody2D> ();
		initvel = mybody.velocity;
		maxvel = initvel.magnitude;
	}

	// Update is called once per frame
	public override void Update () {
		base.Update ();
		if (mybody.velocity.magnitude <= maxvel+.01f && boomeranging) {
			mybody.AddForce (-initvel.normalized * reboundstrength, ForceMode2D.Impulse);
		} else {
			boomeranging = false;
		}
	}
}
