﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class AbstractSpecial : MonoBehaviour {

	public float lifetime = .2f;
	public float age = 0f;
	public GameObject[] particles;

	// Use this for initialization
	protected virtual void Start () {
		foreach (GameObject p in particles) {
			Instantiate (p, transform.position, transform.rotation);
			p.GetComponent<ParticleSystem> ().Play ();
		}
	}
	
	// Update is called once per frame
	protected virtual void Update () {
		age += Time.deltaTime;
		if (age > lifetime) {
			Debug.Log ("here");
			KillMe ();
		}
	}

	protected virtual void KillMe(){
		Destroy (gameObject);
	}
}
