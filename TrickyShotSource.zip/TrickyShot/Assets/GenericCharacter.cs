﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public abstract class GenericCharacter : MonoBehaviour {

	protected float health;
	public float maxhealth;
	public GameObject UIObject;
	protected FillController healthFill;
	public bool bulletLocked;
	public AudioSource shootsource;
	public AudioClip shootsound;
	public AudioSource hitsource;
	public AudioClip hitsound;
	public GameObject dieObject;
	private bool dead = false;

	// Use this for initialization
	protected virtual void Start () {
		health = maxhealth;
		GameObject UIFollower = Instantiate (UIObject, GameObject.FindGameObjectWithTag ("HUD").transform);
		UIFollower.GetComponent<UIFollowScript> ().followObject = transform;
		healthFill = UIFollower.GetComponent<FillController> ();
		shootsource = gameObject.AddComponent<AudioSource>();
		hitsource = gameObject.AddComponent<AudioSource>();
		shootsource.clip = shootsound;
		hitsource.clip = hitsound;
	}
	
	// Update is called once per frame
	protected virtual void Update () {
		UpdateHealth ();
	}

	public virtual void UpdateHealth (){
		if (health < 0 && !dead) {
			Die ();
			dead = true;
		}
		healthFill.SetFill (health / maxhealth); 
	}

	public virtual void TakeDamage(float damage){
		health -= damage;
	}

	public virtual void Die ()
	{
		DeathSound();
		Camera.main.GetComponent<CameraShake> ().CamShake (.3f);
		Destroy (healthFill.gameObject);
		Destroy (gameObject);
	}
	public virtual void DeathSound(){
		Instantiate (dieObject, transform.position, Quaternion.identity);
	}
}
