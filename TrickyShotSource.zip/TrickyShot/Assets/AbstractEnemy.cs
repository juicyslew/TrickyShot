﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class AbstractEnemy : GenericCharacter {

	public GameObject shotType;
	public float projmult;
	protected float shootTimer = 0f;
	public float shootInterval;
	public float crashdamage;
	public float turnspd;
	private Transform target;
	public EnemySpawner spawner;

	protected float angle = 0f;
	protected bool prefdirleft = false;
	protected float reAimTimer = 0f;
	protected float reAimInterval = .2f;
	protected Vector2 targdir;
	protected float coverRange = 30f * Mathf.Deg2Rad;


	public enum ShootStyle {Idle, Chase, Shoot, Dodge, Cover, Random};
	public ShootStyle shoottype;

	protected override void Start(){
		base.Start ();
		target = GameObject.FindGameObjectWithTag ("Player").transform;

		if (Random.value > .5) {
			prefdirleft = true;
		}
	}

	// Use this for initialization
	
	// Update is called once per frame
	protected override void Update () {
		Rotate ();
		Shoot ();
		base.Update();
	}

	protected virtual void OnTriggerEnter2D(Collider2D col){
		if (col.gameObject.tag == "Player") {
			col.gameObject.GetComponent<PlayerScript>().hitsource.Play ();
			Camera.main.GetComponent<CameraShake> ().CamShake (.07f);
			col.GetComponent<GenericCharacter> ().TakeDamage(crashdamage);
			Die ();
		}
	}

	protected virtual void Rotate(){
		switch (shoottype) {
		case ShootStyle.Idle:
		case ShootStyle.Shoot:
			targdir = FaceTarget (target, 0);
			break;
		case ShootStyle.Chase:
			targdir = FaceTarget (target, Mathf.PI);
			break;

		case ShootStyle.Dodge:
			targdir = FaceTarget (target, prefdirleft ? Mathf.PI/2 : -Mathf.PI/2);
			break;

		case ShootStyle.Cover:
			if (reAimTimer > reAimInterval) {
				targdir = FaceTarget (target, (Random.value-.5f) * coverRange);
				reAimTimer = 0f;
			}
			break;

		case ShootStyle.Random:
			if (reAimTimer > reAimInterval) {
				targdir = FaceTarget (target, (Random.value-.5f) * Mathf.PI * 2);
				reAimTimer = 0f;
			}
			break;
		}

		float angvel = Mathf.Clamp(((Vector2) transform.up).SAngle(targdir), -1, 1) * turnspd; 
		angle += angvel * Time.deltaTime;

		transform.up = new Vector2 (Mathf.Cos (angle), Mathf.Sin (angle));
		reAimTimer += Time.deltaTime;
	}

	protected Vector2 FaceTarget(Transform focus, float angoff){
		Vector2 targdir = (Vector2) (focus.position - transform.position);
		float sinang = Mathf.Sin(angoff);
		float cosang = Mathf.Cos(angoff);
		Vector2 lookdir = new Vector2(
			-sinang * targdir.y + cosang * targdir.x, 
			sinang * targdir.x + cosang * targdir.y);

		return lookdir;
	}


	protected virtual void Shoot(){
		if (shootTimer > shootInterval && shoottype != ShootStyle.Idle){
			shootsource.Play ();
			float shotspd = shotType.GetComponent<AbstractBullet> ().speed;
			GameObject bullet = Instantiate (shotType, transform.position, transform.rotation);
			AbstractBullet velscript = bullet.GetComponent<AbstractBullet>();
			velscript.speed = shotspd * projmult;
			velscript.player = this;
			shootTimer = 0f;
		}
		shootTimer += Time.deltaTime;
	}

	public override void Die(){
		if (spawner) {
			spawner.numActiveObj -= 1;
		}
		base.Die ();
	}
}
