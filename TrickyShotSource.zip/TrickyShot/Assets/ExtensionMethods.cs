﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public static class ExtensionMethods {

	public static float SAngle(this Vector2 v1, Vector2 v2){
		Vector2 checkvec = new Vector2 (-v1.y, v1.x); // Rotated 90 degrees counterclockwise
		float ang = Vector2.Angle (v1, v2);
		float dot = checkvec.x * v2.x + checkvec.y * v2.y;
		return ang * ((dot>0) ? 1 : -1);
	}
}
