﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class AbstractSpawner : MonoBehaviour {

	public GameObject[] objects;
	public float[] prevalence;
	public float maxObjects;
	public float numActiveObj;
	protected float spawnTimer;
	public float spawnInterval = 2.5f;
	protected GameObject player;
	protected float playerboundary = .2f;

	// Use this for initialization
	protected virtual void Start () {
		player = GameObject.FindGameObjectWithTag ("Player");
		spawnTimer = spawnInterval;
		numActiveObj = 0;
		float sum = 0;
		foreach (float f in prevalence) {
			sum += f;
		}
		for (int i = 0; i < prevalence.Length; i++) {
			prevalence [i] = prevalence [i] / sum;
		}
	}

	protected virtual void Update(){
		spawnTimer += Time.deltaTime;
		CheckSpawn ();
	}

	public virtual GameObject RandomSpawn(Vector3 loc){
		float sum = 0;
		float randval = Random.value;
		for (int i = 0; i < prevalence.Length; i++) {
			sum += prevalence [i];
			if (randval < sum){
				GameObject p = Instantiate (objects [i], loc, Quaternion.identity);
				return p;
			}
		}
		return null; //Should never get here
	}

	public virtual void CheckSpawn(){
		if (spawnTimer > spawnInterval && numActiveObj < maxObjects) {
			spawnTimer = 0;
			Vector3 spawnpos = GenerateSpawnLocation ();
			spawnpos.z = transform.position.z;
			RandomSpawn (spawnpos);
			numActiveObj += 1;
		}
	}
	public virtual Vector3 GenerateSpawnLocation(){
		Vector2 testspot;
		while (true){
			testspot = new Vector2 (Random.value * .8f + .1f, Random.value * .8f + .1f);
			if (((Vector2)Camera.main.WorldToViewportPoint (player.transform.position) - testspot).magnitude > playerboundary) {
				break;
			}
		}
		return testspot;
	}
}
