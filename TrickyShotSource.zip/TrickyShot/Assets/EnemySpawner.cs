﻿using System.Linq;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;


public class EnemySpawner : AbstractSpawner {

	private float numObjectives = 6;
	public bool randomObjectives;

	public override GameObject RandomSpawn(Vector3 loc){
		GameObject obj = base.RandomSpawn (loc);
		AbstractEnemy enemy = obj.GetComponent<AbstractEnemy> ();
		if (randomObjectives) {
			enemy.bulletLocked = (Random.value > .5f) ? true : false;
			enemy.shoottype = (AbstractEnemy.ShootStyle)Random.Range(0, numObjectives);
		}
		enemy.spawner = this;
		return obj;
	}
}
